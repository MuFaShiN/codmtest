# CoDM ESP & Aimbot Mod Menu
This project was been shared on a telegram group, I will reshare here publicly so it is more known

![](photo_2022-10-30_20-31-04.jpg)

# Features
- Auto update
- ESP Player Line, Box, Health, Name, Distance
- Aimbot
- Aim Location
- Arm Target
- Size POV
- Trigger
- AS and AIDE supported

# Credits
Me and me only no one else deserve the credit except orignal creator. Fuckk all copy pasters here useless shits dont even know to handle pointer and call them selves a native modder suck my d**k

# DISCLAIMER
**THE SOURCE IS OLD AND REPLACED WITH NEW FILES SO THE KNOWN BUG HAS BEEN FIXED AND MORE YOU MUST UPDATE AND FIX ERROS BY YOURSELF! NO QUESTION ASKED!**

**THIS PROJECT IS FOR EDUCATIONAL USE ONLY. WE DO NOT CONDONE THIS PROJECT BEING USED TO GAIN AN ADVANTAGE AGAINST OTHER PEOPLE. WE ARE NOT RESPONSIBLE FOR ANY DAMAGES**
